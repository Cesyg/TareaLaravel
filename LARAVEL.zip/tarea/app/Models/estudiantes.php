<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class estudiantes extends Model
{
    use HasFactory;
    protected $table ="estudiantes";
    protected $fillable = ["carne",
    "nombres",
    "apellidos",
    "direccion",
    "telefono",
    "correo",
    "id_tipos_sangre",
    "fecha_nacimiento",
];
protected $dates = ["fecha_nacimiento"];
}
