@extends('tema.app')

@section('title', "Inicio")

@section('contenido')
   <h3>
    Registrar Estudiantes
   </h3>
   <form action="javascript:void(0);">
    <div class="row">
        <div class="col-sm-12">
          <label for="InputCarne" class="form-label">* Carne</label>
          <input type="text" name="carne" id="InputCarne" class="form-control" placeholder="...">
        </div>
        <div class="col-sm-12">
            <label for="InputNombres" class="form-label">* Nombres</label>
            <input type="text" name="nombres" id="InputNombres" class="form-control" placeholder="...">
          </div>
          <div class="col-sm-12">
            <label for="InputApellidos" class="form-label">* Apellidos</label>
            <input type="text" name="apellidos" id="InputApellidos" class="form-control" placeholder="...">
          </div>
          <div class="col-sm-12">
            <label for="InputDireccion" class="form-label">* Direccion</label>
            <input type="text" name="direccion" id="InputDireccion" class="form-control" placeholder="...">
          </div>
          <div class="col-sm-12">
            <label for="InputTelefono" class="form-label">* Telefono</label>
            <input type="text" name="Telefono" id="InputTelefono" class="form-control" placeholder="...">
          </div>
          <div class="col-sm-12">
            <label for="InputCorreo" class="form-label">* Correo</label>
            <input type="text" name="correo" id="InputCorreo" class="form-control" placeholder="...">
          </div>
          <div class="col-sm-12">
            <label for="InputTipoSangre" class="form-label">* TipoSangre</label>
            <input type="text" name="tiposangre" id="InputTipoSangre" class="form-control" placeholder="...">
          </div>
          <div class="col-sm-12">
            <label for="InputFechaNacimiento" class="form-label">* FechaNacimiento</label>
            <input type="date" name="FechaNacimiento" id="InputFechaNacimiento" class="form-control">
          </div>
        <div class="col-md-1 text-end">
            <button type="submit" class="btn btn-primary">
                Agregar
            </button>
        </div>
        <div class="col-md-1 text-end">
            <button type="submit" class="btn btn-primary">
                Modificar
            </button>
        </div>
        <div class="col-md-1 text-end">
            <button type="submit" class="btn btn-danger">
                Eliminar
            </button>
        </div>
    </div>
   </form> 
   @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
   @endsection